// LeftSidebar.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const MenuItem = ({ item }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleToggle = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <li>
      <div onClick={handleToggle} style={{ cursor: 'pointer' }}>
        <Link to={item.path}>{item.name}</Link>
      </div>
      {isExpanded && item.children && (
        <ul>
          {item.children.map((child) => (
            <MenuItem key={child.id} item={child} />
          ))}
        </ul>
      )}
    </li>
  );
};

const LeftSidebar = ({ menuData }) => {
  return (
    <div style={{ width: '200px', position: 'fixed', left: 0, top: 0, height: '100%', background: '#f5f2e9', color: '#fff' }}>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {menuData.map((item) => (
          <MenuItem key={item.id} item={item} />
        ))}
      </ul>
    </div>
  );
};

export default LeftSidebar;
